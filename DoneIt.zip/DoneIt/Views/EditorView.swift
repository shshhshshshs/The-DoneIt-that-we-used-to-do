// Views/EditorView.swift
import SwiftUI
import PencilKit

struct PKCanvasRepresentable: UIViewRepresentable {
    @Binding var drawing: PKDrawing
    var finger: Bool
    func makeUIView(context: Context) -> PKCanvasView {
        let v = PKCanvasView()
        v.drawing = drawing
        v.backgroundColor = .clear
        v.isOpaque = false
        v.allowsFingerDrawing = finger == true
        return v
    }
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        uiView.drawing = drawing
        uiView.allowsFingerDrawing = finger
    }
}

struct EditorView: View {
    @StateObject var vm = EditorViewModel()
    var body: some View {
        ZStack {
            PKCanvasRepresentable(drawing: $vm.drawing, finger: false)
            TextEditor(text: $vm.text)
                .opacity(vm.mode == .text ? 1 : 0.001)
                .background(Color.clear)
                .padding(.horizontal, 8)
        }
        .onAppear { vm.loadOrCreate() }
        .toolbar {
            ToolbarItemGroup(placement: .bottomBar) {
                Button {
                    vm.toggleMode()
                } label {
                    Image(systemName: vm.mode == .ink ? "character.cursor.ibeam" : "pencil.tip")
                }
                Spacer()
                Button {
                    vm.save()
                } label { Image(systemName: "square.and.arrow.down") }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
