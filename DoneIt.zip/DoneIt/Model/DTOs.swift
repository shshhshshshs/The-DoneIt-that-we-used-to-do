// Model/DTOs.swift
import Foundation
import CoreGraphics

public struct NoteID: Hashable, Codable { public let uuid: UUID }
public struct BlockID: Hashable, Codable { public let uuid: UUID }
public struct StrokeID: Hashable, Codable { public let uuid: UUID }

public enum BlockType: Int, Codable {
    case paragraph, heading, canvas, list, quote
}

public struct NoteDTO: Codable, Identifiable {
    public var id: NoteID
    public var title: String
    public var createdAt: Date
    public var updatedAt: Date
    public var keywords: [String]
    public init(id: NoteID = .init(uuid: .init()),
                title: String = "",
                createdAt: Date = .init(),
                updatedAt: Date = .init(),
                keywords: [String] = []) {
        self.id = id; self.title = title; self.createdAt = createdAt
        self.updatedAt = updatedAt; self.keywords = keywords
    }
}

public struct BlockDTO: Codable, Identifiable {
    public var id: BlockID
    public var noteId: NoteID
    public var type: BlockType
    public var text: String
    public var order: Int
    public var styleJSON: String?
    public init(id: BlockID = .init(uuid: .init()),
                noteId: NoteID, type: BlockType, text: String = "", order: Int = 0, styleJSON: String? = nil) {
        self.id = id; self.noteId = noteId; self.type = type; self.text = text; self.order = order; self.styleJSON = styleJSON
    }
}

public struct StrokeDTO: Codable, Identifiable {
    public var id: StrokeID
    public var noteId: NoteID
    public var blockId: BlockID
    public var bbox: CGRect
    public var archiveURL: String // .drawing file path (string)
}
