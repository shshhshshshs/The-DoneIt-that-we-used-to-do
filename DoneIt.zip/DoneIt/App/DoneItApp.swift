// App/DoneItApp.swift
import SwiftUI

@main
struct DoneItApp: App {
    var body: some Scene {
        WindowGroup { RootView().primaryTint() }
    }
}

struct RootView: View {
    @StateObject var vm = SearchViewModel()
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                EditorView()
                Divider()
                HStack {
                    TextField("搜索…", text: $vm.query)
                        .textFieldStyle(.roundedBorder)
                    Button {
                        vm.run()
                    } label { Image(systemName: "magnifyingglass") }
                }.padding()
                List(vm.results) { r in Text(r.snippet) }
            }
            .navigationTitle("DoneIt 25")
        }
    }
}
