// App/AppContainer.swift
import Foundation

final class AppContainer {
    static let shared = AppContainer()
    var notes: NoteRepository = NoteRepoImplStub()
    var blocks: BlockRepository = BlockRepoImplStub()
    var strokes: StrokeStore = StrokeStoreImplStub()
    var search: SearchIndexing = SearchIndexImplStub()
    var persona: PersonaParsing = PersonaParserImplStub()
}

// MARK: Stubs —— Codex 要把这些替换成真实 Impl
private struct NoteRepoImplStub: NoteRepository {
    func create(_ note: NoteDTO) throws {}
    func update(_ note: NoteDTO) throws {}
    func fetch(id: NoteID) -> NoteDTO? { .init(id: id, title: "Stub") }
    func recent(limit: Int) -> [NoteDTO] { [.init(title: "Welcome")] }
}
private struct BlockRepoImplStub: BlockRepository {
    func blocks(of note: NoteID) -> [BlockDTO] { [] }
    func upsert(_ block: BlockDTO) throws {}
}
private struct StrokeStoreImplStub: StrokeStore {
    func saveStroke(_ stroke: StrokeDTO) throws {}
    func strokes(of block: BlockID) -> [StrokeDTO] { [] }
}
private struct SearchIndexImplStub: SearchIndexing {
    func upsert(note: NoteDTO, blocks: [BlockDTO]) {}
    func search(_ q: String, limit: Int) -> [SearchHit] { [] }
}
private struct PersonaParserImplStub: PersonaParsing {
    func parse(_ src: String) throws -> PersonaDoc {
        PersonaDoc(title: "DoneIt 25", blocks: [.h1("DoneIt 25"), .text("Personal workstation."), .canvas(id: "ink")], keywords: ["BETA"])
    }
}
