// ViewModel/SearchViewModel.swift
import Foundation

@MainActor
final class SearchViewModel: ObservableObject {
    @Published var query: String = ""
    @Published var results: [SearchHit] = []
    private let search = AppContainer.shared.search

    func run() { results = search.search(query, limit: 20) }
}
