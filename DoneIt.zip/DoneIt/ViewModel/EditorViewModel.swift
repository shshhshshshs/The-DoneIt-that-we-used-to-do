// ViewModel/EditorViewModel.swift
import Foundation
import PencilKit

@MainActor
final class EditorViewModel: ObservableObject {
    @Published var text: String = ""
    @Published var mode: Mode = .ink
    @Published var drawing = PKDrawing()
    enum Mode { case ink, text }

    private let container = AppContainer.shared
    private var current: NoteDTO = .init(title: "")

    func loadOrCreate() {
        if let n = container.notes.recent(limit: 1).first { current = n }
        else {
            current = .init(title: "New Note")
            try? container.notes.create(current)
        }
    }

    func save() {
        // 最简：把文本作为一个 paragraph block；画笔单独归档文件由 Codex 的 SaveService 处理
        let block = BlockDTO(noteId: current.id, type: .paragraph, text: text, order: 0)
        try? container.blocks.upsert(block)
        try? container.notes.update(current)
        container.search.upsert(note: current, blocks: [block])
    }

    func toggleMode() { mode = (mode == .ink ? .text : .ink) }
}
