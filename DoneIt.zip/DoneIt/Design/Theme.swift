// Design/Theme.swift
import SwiftUI
enum AppTheme {
    static let primary = Color(red: 0x4B/255.0, green: 0x2E/255.0, blue: 0x83/255.0) // deep purple
}
extension View { func primaryTint() -> some View { tint(AppTheme.primary) } }
